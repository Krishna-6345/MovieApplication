export class user{

    constructor(
        public userName:string,
        public password:string,
        public phoneNumber:string,
        public gender:string,
        public emailId:string,
        public profilePhoto:string
      ){}

}