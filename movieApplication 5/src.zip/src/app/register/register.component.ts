import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { user } from '../user';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  

  user: user=new user("","","","","","");

  
  constructor() { }


  registerNow()
  {
    //this.router.navigate(['/login']);
  }

  


  ngOnInit(): void {
   
  
  }

  registerForm= new FormGroup(
  {
   
      userName: new FormControl(['',Validators.required]),
      password:new FormControl('',Validators.required),
      // phoneNumber:new FormControl(['',Validators.required]),
      emailId:new FormControl('',Validators.required),
      gender:new FormControl('',Validators.required),
      // profilePhoto:new FormControl('',Validators.required)
  })
  
  



  register()
  {
    // let userDetails = this.registerForm.value;
    // // userDetails.movies = [this.movie];
    // this.register.registration(this.registerForm.value).subscribe(
    //   (data:any)=>{
    //     console.log(data);
    //     alert('User Registered Sucessfully')
    //   }
    // );
  }

}
